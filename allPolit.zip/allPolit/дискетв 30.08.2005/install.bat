@ECHO Installing Polit on disk A:
@RAWWRITE.EXE POLITDSK.IMG