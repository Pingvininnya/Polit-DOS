// (C) 2002 ybx
unit regint;

interface

type Registers=record
                case Integer of
0: (AX, BX, CX, DX, BP, SI, DI, DS, ES, Flags: smallWord);
1: (AL, AH, BL, BH, CL, CH, DL, DH: Byte);

                end;

procedure Intr(IntNo: Byte; var Regs: Registers);


implementation
uses dpmi32df,dpmi32;
var rdregs:real_mode_call_structure_typ;



procedure Intr(IntNo: Byte; var Regs: Registers);
begin
  init_register(rdregs);
  rdregs.ax_:=Regs.AX;
  rdregs.bx_:=Regs.CX;
  rdregs.cx_:=Regs.CX;
  rdregs.dx_:=Regs.DX;
  intr_realmode(rdregs,IntNo);
  Regs.AX:=rdregs.ax_;
  Regs.BX:=rdregs.bx_;
  Regs.CX:=rdregs.cx_;
  Regs.DX:=rdregs.dx_;
end;

end.
