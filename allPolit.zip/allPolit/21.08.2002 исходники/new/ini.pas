Unit
	Ini; { Polit Halcyon Eva ini files support unit }

Interface

Uses
	Types,D,Log;

Const
	MaxSectionsNum=12;
	MaxRecordsNum=120;
	MaxIniFilesNum=45;
	DefaultIniPath:String='';

Type
	TIniSection=Record
		Name:PStr;
		FirstLine:Integer
	End;

	TIniRecord=Record
		Key,Value:PStr
	End;

	TIniFile=Record
		Section:Array[1..MaxSectionsNum] Of TIniSection;
		SecNum:Integer;
		Rec:Array[1..MaxRecordsNum] Of TIniRecord;
		RecNum:Integer;
		CurSec:Integer;
		Name:String[8]
	End;


	Procedure SetFile(FName:String);
	Procedure Load(Name:String);
	Function GetStr(VKey,Default:String):String;
	Function GetInt(VKey:String;Default:Integer):Integer;
	Function GetBool(VKey:String;Default:Boolean):Boolean;
	Procedure SetSection(VSection:String);
	Procedure Init;
	Procedure Done;

Var
	OK:Boolean;

Implementation

Var
	IniF:Array[1..MaxIniFilesNum] Of ^TIniFile;
	FilesNum:Integer;
	IFT:Text;
	CurFile:Integer;
	CurFileName:String[8];
	UpCaseNeeded:Boolean;


Function FindFileName(FName:String):Integer;
Var
	V,VF:Integer;
Begin
	VF:=0;
	For V:=1 To FilesNum Do
		If IniF[V]^.Name=FName Then
			VF:=V;
	FindFileName:=VF
End;

Procedure SetFile(FName:String);
Var
	V:Integer;
Begin
	V:=FindFileName(FName);
	If V>0 Then
	Begin
		CurFile:=V;
		Log.SysMsg('Ini','SetCurFile','Current file set: '+FName);
		OK:=True
	End
	Else Begin
		Log.ErrMsg('Ini','SetCurFile','There is no such file: '+FName);
		OK:=False
	End
End;

Procedure Load(Name:String);
Var
	TL:String;
	TempI,CurL:Integer;
	VP:Byte;
	VF:Integer;
Begin
	Log.SysMsg('Ini','Load','Loading INI file: '+DefaultIniPath+Name+'.ini');
	Inc(FilesNum);
	New(IniF[FilesNum]);
	IniF[FilesNum]^.SecNum:=0;
	IniF[FilesNum]^.RecNum:=0;
	IniF[FilesNum]^.Name:=Name;
	IniF[FilesNum]^.CurSec:=1;
	CurFile:=FilesNum;

	If Not D.FileExist(DefaultIniPath+Name+'.ini') Then
	Begin
		Log.ErrMsg('Ini','Load','File not found');
		Log.ActMsg('Creating empty INI structure');
		OK:=False;
		Exit
	End;
	Assign(IFT,DefaultIniPath+Name+'.ini');
	Reset(IFT);
	TempI:=IOResult;
	CurL:=1;
	Repeat
		ReadLn(IFT,TL);
		VP:=Pos(';',TL);
		If VP<>0 Then
			TL:=Copy(TL,1,VP-1);
		D.TrimSpaces(TL);

		If TL<>'' Then
			If TL[1]='[' Then
				With IniF[FilesNum]^ Do
				Begin { ��������� ᥪ�i� }
					Inc(SecNum);
					If TL[Length(TL)]<>']' Then
					Begin
						Log.ErrMsg('Ini','Load','Ini file section header have no closing ]: '+TL);
						Log.ActMsg('Treating it as '+TL+']');
						D.AssignPStr(Copy(TL,2,Length(TL)-1),Section[SecNum].Name)
					End
					Else
						D.AssignPStr(Copy(TL,2,Length(TL)-2),Section[SecNum].Name);
					Section[SecNum].FirstLine:=CurL
				End
			Else Begin
				VP:=Pos('=',TL);
				If VP<>0 Then
					With IniF[FilesNum]^ Do
					Begin { �冷� ��ࠬ���=���祭�� }
						Inc(RecNum);
						D.AssignPStr(Copy(TL,1,VP-1),Rec[RecNum].Key);
						D.AssignPStr(Copy(TL,VP+1,Length(TL)-VP),Rec[RecNum].Value);
						Inc(CurL)
					End
			End
	Until EOF(IFT);
	Close(IFT);
	OK:=True
End;

Function KeyIndex(VKey:String):Integer;
Var
	V,VF,VL:Integer;
Begin
	With IniF[CurFile]^ Do
	Begin
		VF:=0;
		If CurSec=SecNum
			Then VL:=RecNum
			Else VL:=Section[CurSec+1].FirstLine-1;
		For V:=Section[CurSec].FirstLine To VL Do
			If UpCaseLine(String(Rec[V].Key^))=VKey Then
				VF:=V;
		KeyIndex:=VF
	End
End;

Function GetStr(VKey,Default:String):String;
Var
	V:Integer;
Begin
	VKey:=D.UpCaseLine(VKey);
	V:=KeyIndex(VKey);
	If V=0 Then
	Begin
		Log.ErrMsg('Ini','GetStr','Key not found: '+VKey);
		Log.ActMsg('Returning default string: '+Default);
		GetStr:=Default;
		OK:=False
	End
	Else Begin
		If UpCaseNeeded
			Then GetStr:=D.UpCaseLine(String(IniF[CurFile]^.Rec[V].Value^))
			Else GetStr:=String(IniF[CurFile]^.Rec[V].Value^);
		OK:=True
	End;
End;

Function GetInt(VKey:String;Default:Integer):Integer;
Var
	V,Temp:Integer;
	Res:Word;
Begin
	VKey:=D.UpCaseLine(VKey);
	V:=KeyIndex(VKey);
	If V=0 Then
	Begin
		Log.ErrMsg('Ini','GetInt','Key not found: '+VKey);
		Log.ActMsg('Returning default value: '+D.St(Default));
		GetInt:=Default;
		OK:=False
	End
	Else Begin
		Val(String(IniF[CurFile]^.Rec[V].Value^),Temp,Res);
		If Res<>0 Then
		Begin
			Log.ErrMsg('Ini','GetInt','Key value is not integer: '+
				VKey+'='+String(IniF[CurFile]^.Rec[V].Value^));
			Log.ActMsg('Returning default value: '+D.St(Default));
			GetInt:=Default;
			OK:=False
		End
		Else Begin
			GetInt:=Temp;
			OK:=True
		End
	End
End;

Function GetBool(VKey:String;Default:Boolean):Boolean;
Var
	V:Integer;
	Temp:String;
Begin
	VKey:=D.UpCaseLine(VKey);
	V:=KeyIndex(VKey);
	If V=0 Then
	Begin
		Log.ErrMsg('Ini','GetBool','Key not found: '+VKey);
		If Default
			Then Log.ActMsg('Returning default value: True')
			Else Log.ActMsg('Returning default value: False');
		GetBool:=Default;
		OK:=False
	End
	Else Begin
		Temp:=D.UpCaseLine(String(IniF[CurFile]^.Rec[V].Value^));
		If (Temp='YES') Or (Temp='TRUE') Or (Temp='1')
			Then GetBool:=True
			Else GetBool:=False;
		OK:=True
	End;
End;



Function SectionIndex(VSection:String):Integer;
Var
	V,VF:Integer;
Begin
	VSection:=UpCaseLine(VSection);
	With IniF[CurFile]^ Do
	Begin
		VF:=0;
		For V:=1 To SecNum Do
			If UpCaseLine(String(Section[V].Name^))=VSection Then
				VF:=V;
		SectionIndex:=VF
	End
End;

Procedure SetSection(VSection:String);
Var
	V:Integer;
Begin
	V:=SectionIndex(VSection);
	If V=0 Then Begin
		Log.ErrMsg('Ini','SetSection','Section not found: '+VSection);
		With IniF[CurFile]^ Do
			Log.ActMsg('Section ['+String(Section[CurSec].Name^)+'] remains current');
		OK:=False
	End
	Else Begin
		IniF[CurFile]^.CurSec:=V;
		OK:=True
	End
End;


Procedure Init;
Begin
	FilesNum:=0;
	UpCaseNeeded:=True;
	OK:=True
End;

Procedure Done;
Begin
	OK:=False
End;

Begin End.