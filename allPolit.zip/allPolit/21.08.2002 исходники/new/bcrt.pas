{$A-,B-,D-,E-,F-,G-,I-,L-,N-,O-,P-,Q-,R-,S-,T-,V-,X-,Y-}
{$M 16384,0,0}
Unit BCRT;

Interface
 Procedure Delay(MS: Word);

 Const BW40    = 0;   { 40x25 B/W         CGA}
       CO40    = 1;   { 40x25 Color       CGA}
       BW80    = 2;   { 80x25 B/W         CGA}
       CO80    = 3;   { 80x25 Color       CGA}
       Mono    = 7;   { 80x25 B/W on MDA  HGC}
       Font8x8 = 255; { 43-/50-line mode  EGA/VGA}
       C40     = CO40;
       C80     = CO80;

       Black     = 0;
       Blue      = 1;
       Green     = 2;
       Cyan      = 3;
       Red       = 4;
       Magenta   = 5;
       Brown     = 6;
       LightGray = 7;

       DarkGray     =  8;
       LightBlue    =  9;
       LightGreen   = 10;
       LightCyan    = 11;
       LightRed     = 12;
       LightMagenta = 13;
       Yellow       = 14;
       White        = 15;

       Blink        = 128;

 Const CheckBreak: Boolean  = True;
       CheckEOF: Boolean    = False;
       DirectVideo: Boolean = True;
       CheckSnow: Boolean   = False;
 Var LastMode: Word;
     TextAttr: Word;
     v0058,v0059,v005A,v005B: Byte;
     WindMin: Word absolute v0058;
     WindMax: Word absolute v005A;

 Procedure AssignCRT(var f:Text);
       {Associates a text file with the CRT window.}
 Procedure ClrEol;
       {Clears all the characters from the cursor position
        to the end of the line.}
 Procedure ClrScr;
       {Clears the screen and returns the cursor to the
        upper left corner.}
 Procedure DelLine;
       {Deletes the line containing the cursor.}
 Procedure GotoXY(X,Y:Byte);
       {Moves the cursor to the given coordinates within
        the virtual screen.}
 Procedure HighVideo;
       {Selects high-intensity characters.}
 Procedure InsLine;
       {Inserts an empty line at the cursor position.}
 Function KeyPressed:Boolean;
       {Determines if a key has been pressed on the
        keyboard.}
 Procedure LowVideo;
       {Selects low-intensity characters.}
 Procedure NormVideo;
       {Selects the original text attribute read from the
        cursor location at startup.}
 Procedure NoSound;
       {Turns off the computer's internal speaker.}
 Function ReadKey:Char;
       {Reads a character from the keyboard.}
 Procedure Sound(Hz: Word);
       {Proc � Starts the internal speaker.}
 Procedure TextBackground(Color: Byte);
       {Selects the background color.}
 Procedure TextColor(Color: Byte);
       {Selects the foreground character color.}
 Procedure TextMode(Mode: Integer); Far;
       {Selects a specific text mode.}
 Function WhereX:Byte;
       {Returns the X coordinate of the current cursor
        location.}
 Function WhereY:Byte;
       {Returns the Y coordinate of the current cursor
        location.}
 Procedure Window(X1, Y1, X2, Y2: Byte);
       {Defines a text window on the screen.}

Implementation
 Const Pause:record
              case boolean of
                 true:  (DWord: LongInt);
                 false: (WordLo,WordHi:Word)
              end = (DWord: 0);

 Var v005E,v005F,v0060,v0061,v0062:byte;

 Procedure f_0000;
  Begin
   Halt (255)
  End;

 Procedure Count; Assembler;
 ASM
@@begin:
  sub   dx,$01
  sbb   ax,$00
  jb    @@end
  cmp   bl,es:[di]
  je    @@begin
@@end:
 END;

 Procedure Delay(MS: Word); Assembler;
  ASM
   mov   cx,MS
   jcxz  @@end
   mov   es,seg0040
   xor   di,di
   mov   bl,es:[di]
@@loop:
   mov   dx,Pause.WordLo
   mov   ax,Pause.WordHi
   call  count
   loop  @@loop
@@end:
  END;

 Procedure f_0614; Assembler;
  ASM
   push  si
   push  di
   push  bp
   push  es
   int   $10
   pop   es
   pop   bp
   pop   di
   pop   si
  END;

 Procedure f_00F0; Assembler;
  ASM
   mov   ah,$0F
   call  f_0614
   push  ax
   mov   ax,$1130
   mov   bh,$00
   mov   dl,$00
   call  f_0614
   pop   ax
   mov   cl,$00
   or    dl,dl
   jne   @@010F
   mov   dl,$18
   cmp   al,$03
   ja    @@010F
   mov   cl,$01
@@010F:
   mov   dh,dl
   mov   dl,ah
   dec   dl
   mov   ah,$00
   cmp   dh,$18
   jbe   @@011E
   mov   ah,$01
@@011E:
   mov   LastMode,ax
   mov   word ptr v005E,dx
   mov   CheckSnow,cl
   mov   byte ptr DirectVideo,$01
   xor   ax,ax
   mov   WindMin,ax
   mov   WindMax,dx
  END;

 Procedure f_0138; Interrupt; Assembler;
  ASM
   push  ax
   push  ds
   mov   ax,SEG v0062
   mov   ds,ax
   cmp   byte ptr CheckBreak,$00
   je    @@014B
   mov   byte ptr v0062,$01
@@014b:
   pop   ds
   pop   ax
  END;

 Procedure f_00A3; Assembler;
  ASM
   mov   es,Seg0040
   and   es:byte ptr [$0087],$FE
   cmp   al,$07
   je    @@00B7
   cmp   al,$04
   jb    @@00B7
   mov   al,$03
@@00b7:
   push  ax
   mov   ah,$00
   call  f_0614
   pop   ax
   or    ah,ah
   je    @@00EF
   mov   ax,$1112
   mov   bl,$00
   call  f_0614
   mov   ax,$1130
   mov   bh,$00
   mov   dl,$00
   call  f_0614
   cmp   dl,$2A
   jne   @@00EF
   or    es:byte ptr [$0087],$01
   mov   ax,$0100
   mov   cx,$0600
   call  f_0614
   mov   ah,$12
   mov   bl,$20
   call  f_0614
@@00EF:
  END;

 Procedure Init; Assembler;
  ASM
   mov   ah,$0F
   call  f_0614
   cmp   al,$07
   je    @@004E
   cmp   al,$03
   jbe   @@004E
   mov   ax,$0003
   call  f_00A3
@@004E:
   call  f_00F0
   mov   ah,$08
   xor   bh,bh
   call  f_0614
   mov   al,ah
   and   al,$7F
   mov   v0060,al
   mov   byte ptr TextAttr,al
   xor   ax,ax
   mov   CheckEof,al
   mov   word ptr v0061,ax
   inc   ax
   mov   CheckBreak,al

   mov   es,seg0040
   mov   di,$06C
   mov   dl,es:[di]
@@loop:
   mov   bl,es:[di]
   cmp   dl,bl
   je    @@loop
   mov   dx,$0FFE4
   mov   al,dh
   cbw
   call  count
   not   ax
   not   dx
   mov   cx,$0037
   push  dx
   xor   dx,dx
   div   cx
   mov   Pause.WordHi,ax
   pop   ax
   div   cx
   mov   Pause.WordLo,ax

   push  ds
   push  cs
   pop   ds
   mov   dx,OFFSET f_0138
   mov   ax,$251B
   int   $21
   pop   ds
  END;

 Procedure f_0503; Assembler;
  ASM
   mov   ah,$03
   xor   bh,bh
   jmp   f_0614
  END;

 Procedure f_04E2; Assembler;
  ASM
   inc   dh
   cmp   dh,v005B
   jna   @@0502
   dec   dh
   push  cx
   push  dx
   mov   ax,$0601
   mov   bh,byte ptr TextAttr
   mov   cx,WindMin
   mov   dx,WindMax
   call  f_0614
   pop   dx
   pop   cx
@@0502:
  END;

 Procedure f_050A; Assembler;
  ASM
   mov   ah,$02
   xor   bh,bh
   jmp   f_0614
  END;

 Procedure f_0489; Assembler;
  ASM
   push  bx
   push  cx
   push  dx
   push  es
   push  ax
   call  f_0503
   pop   ax
   cmp   al,$07
   jz    @@04C0
   cmp   al,$08
   jz    @@04C7
   cmp   al,$0D
   jz    @@04D1
   cmp   al,$0A
   jz    @@04D7
   mov   ah,$09
   mov   bl,byte ptr TextAttr
   xor   bh,bh
   mov   cx,$0001
   push  dx
   call  f_0614
   pop   dx
   inc   dl
   cmp   dl,byte ptr WindMax
   jna   @@04DA
   mov   dl,byte ptr WindMin
   jmp   @@04D7
@@04C0:
   mov   ah,$0E
   call  f_0614
   jmp   @@04DA
@@04C7:
   cmp   dl,byte ptr WindMin
   jz    @@04DA
   dec   dl
   jmp   @@04DA
@@04D1:
   mov   dl,byte ptr WindMin
   jmp   @@04DA
@@04D7:
   call  f_04E2
@@04DA:
   call  f_050A
   pop   es
   pop   dx
   pop   cx
   pop   bx
  END;

 Procedure f_0482; Assembler;
  ASM
   mov   al,$0D
   call  f_0489
   mov   al,$0A
   jmp   f_0489
  END;

 Procedure f_039F; Assembler;
  ASM
   push  bp
   mov   bp,sp
   les   di,[bp+$06]
   mov   dx,es:[di+$04]
   dec   dx
   dec   dx
   mov   si,es:[di+$08]
   les   di,es:[di+$0C]
   xor   bx,bx
@@03B5:
   mov   byte ptr v0061,$00
   push  cs
   call  near ptr ReadKey
   mov   cx,$0001
   cmp   al,$08
   jz    @@03F9
   cmp   al,$13
   jz    @@03F9
   cmp   al,$04
   jz    @@0411
   dec   cx
   cmp   al,$1B
   jz    @@03F9
   cmp   al,$01
   jz    @@03F9
   cmp   al,$06
   jz    @@0411
   cmp   al,$1A
   jz    @@0424
   cmp   al,$0D
   jz    @@0431
   cmp   al,$20
   jc    @@03B5
   cmp   bx,dx
   jz    @@03B5
   mov   es:[bx+di],al
   inc   bx
   call  f_0489
   cmp   bx,si
   jna   @@03B5
   mov   si,bx
   jmp   @@03B5
@@03F9:
   or    bx,bx
   jz    @@03B5
   mov   al,$08
   call  f_0489
   mov   al,$20
   call  f_0489
   mov   al,$08
   call  f_0489
   dec   bx
   loop  @@03F9
   jmp   @@03B5
@@0411:
   cmp   bx,si
   jz    @@03B5
   mov   al,es:[bx+di]
   cmp   al,$20
   jc    @@03B5
   call  f_0489
   inc   bx
   loop  @@0411
   jmp   @@03B5
@@0424:
   cmp   CheckEof,$00
   jz    @@03B5
   mov   es:[bx+di],al
   inc   bx
   jmp   @@043B
@@0431:
   call  f_0482
   mov   word ptr es:[bx+di],$0A0D
   inc   bx
   inc   bx
@@043B:
   les   di,[BP+$06]
   xor   ax,ax
   mov   es:[di+$08],ax
   mov   es:[di+$0A],bx
   pop   bp
   retf  $0004
  END;

 Procedure f_05AC; Assembler;
  ASM
   cmp   si,di
   jz    @@0613
   push  cx
   push  dx
   push  di
   push  ds
   push  es
   mov   cx,di
   sub   cx,si
   push  ds
   mov   ds,[Seg0040]
   mov   al,bh
   mul   byte ptr [$004A]
   xor   bh,bh
   add   ax,bx
   shl   ax,1
   mov   di,ax
   mov   dx,[$0063]
   add   dx,$0006
   cmp   byte ptr [$0049],$07
   pop   ds
   mov   ax,[SegB800]
   jnz   @@05E1
   mov   ax,[SegB000]
@@05E1:
   mov   bl,[CheckSnow]
   mov   bh,byte ptr TextAttr
   push  es
   pop   ds
   mov   es,ax
   cld
   or    bl,bl
   jz    @@0608
@@05F2:
   lodsb
   mov   bl,al
@@05F5:
   in    al,dx
   test  al,$01
   jnz   @@05F5
   cli
@@05FB:
   in    al,dx
   test  al,$01
   jz    @@05FB
   mov   ax,bx
   stosw
   sti
   loop  @@05F2
   jmp   @@060E
@@0608:
   mov   ah,bh
@@060A:
   lodsb
   stosw
   loop   @@060A
@@060E:
   pop   es
   pop   ds
   pop   di
   pop   dx
   pop   cx
@@0613:
  END;

 Procedure f_0511; Assembler;
  ASM
   push  ds
   mov   ds,[Seg0040]
   mov   dx,[$0050]
   pop   ds
   mov   bx,dx
   mov   si,di
@@051F:
   mov   al,es:[di]
   cmp   al,$07
   jz    @@0547
   cmp   al,$08
   jz    @@0556
   cmp   al,$0A
   jz    @@0563
   cmp   al,$0D
   jz    @@056B
   inc   di
   inc   dl
   cmp   dl,byte ptr WindMax
   jna   @@0577
   call  f_05AC
   call  f_04E2
   mov   dl,byte ptr WindMin
   jmp   @@0573
@@0547:
   call  f_05AC
   push  cx
   push  dx
   mov   ax,$0E07
   call  f_0614
   pop   dx
   pop   cx
   jmp   @@0572
@@0556:
   call  f_05AC
   cmp   dl,byte ptr WindMin
   jz    @@0572
   dec   dl
   jmp   @@0572
@@0563:
   call  f_05AC
   call  f_04E2
   jmp   @@0572
@@056B:
   call  f_05AC
   mov   dl,byte ptr WindMin
@@0572:
   inc   di
@@0573:
   mov   si,di
   mov   bx,dx
@@0577:
   loop  @@051F
   call  f_05AC
   push  ds
   mov   ds,[Seg0040]
   mov   [$0050],dx
   mov   al,dh
   mul   byte ptr [$004A]
   xor   dh,dh
   add   ax,dx
   mov   cx,ax
   mov   dx,[$0063]
   mov   al,$0E
   out   dx,al
   jmp   @@059A
@@059A:
   mov   al,ch
   inc   dx
   out   dx,al
   jmp   @@05A0
@@05A0:
   dec   dx
   mov   al,$0F
   out   dx,al
   jmp   @@05A6
@@05A6:
   mov   al,cl
   inc   dx
   out   dx,al
   pop   ds
  END;

 Procedure f_014E; Assembler;
  ASM
   cmp   byte ptr v0062,$00
   jne   @@0156
   ret
@@0156:
   mov   byte ptr v0062,$00
@@015b:
   mov   ah,$01
   int   $16
   je    @@0167
   mov   ah,$00
   int   $16
   jmp   @@015B
@@0167:
   mov   al,$5E
   call  f_0489
   mov   al,$43
   call  f_0489
   call  f_0482
   jmp   f_0000
  END;

 Procedure f_044C; Assembler;
  ASM
   mov   bx,sp
   les   di,ss:[bx+$04]
   mov   cx,es:[di+$08]
   sub   es:[di+$08],cx
   jcxz  @@0475
   les   di,es:[di+$0C]
   cmp   DirectVideo,$00
   jnz   @@0472
@@0467:
   mov   al,es:[di]
   call  f_0489
   inc   di
   loop  @@0467
   jmp   @@0475
@@0472:
   call  f_0511
@@0475:
   call  f_014E
   xor   ax,ax
   retf  $0004
  END;

 Procedure f_047D; Assembler;
  ASM
   xor   ax,ax
   retf  $0004
  END;

 Procedure f_0367; Assembler;
  ASM
   mov   bx,sp
   push  ds
   lds   di,ss:[bx+$04]
   mov   ax,OFFSET f_039F
   mov   bx,OFFSET f_047D
   mov   cx,bx
   cmp   word ptr [di+$02],$D7B1
   jz    @@0387
   mov   word ptr [di+$02],$D7B2
   mov   ax,OFFSET f_044C
   mov   bx,ax
@@0387:
   mov   [di+$14],ax
   mov   [di+$16],CS
   mov   [di+$18],bx
   mov   [di+$1A],CS
   mov   [di+$1C],cx
   mov   [di+$1E],CS
   xor   ax,ax
   pop   ds
   retf  $0004
  END;

 Procedure AssignCRT; Assembler;
  ASM
   push  ds
   lds   di,ss:[bp+$04+2]
   mov   word ptr [di+$02],$D7B0
   mov   word ptr [di+$04],$0080
   lea   ax,[$0080+di]
   mov   [di+$0C],ax
   mov   word ptr [di+$10],OFFSET f_0367
   mov   [di+$12],CS
   mov   [di+$0E],ds
   mov   byte ptr [di+$30],$00
   pop   ds
  END;

 Procedure ClrEol; Assembler;
  ASM
   mov   ax,$0600
   mov   bh,byte ptr TextAttr
   mov   cx,dx
   mov   dl,byte ptr WindMax
   call  f_0614
  END;

 Procedure ClrScr; Assembler;
  ASM
   mov   ax,$0600
   mov   bh,byte ptr TextAttr
   mov   cx,WindMin
   mov   dx,WindMax
   call  f_0614
   mov   dx,WindMin
   call  f_050A
  END;

 Procedure GotoXY; Assembler;
  ASM
   mov   dl,ss:[bp+$06+2]
   mov   dh,ss:[bp+$04+2]
   dec   dl
   add   dl,byte ptr WindMin
   jb    @@0248
   cmp   dl,byte ptr WindMax
   ja    @@0248
   dec   dh
   add   dh,v0059
   jb    @@0248
   cmp   dh,v005B
   ja    @@0248
   call  f_050A
@@0248:
  END;

 Procedure HighVideo; Assembler;
  ASM
   or    byte ptr TextAttr,$08
  END;

 Procedure LowVideo; Assembler;
  ASM
   and   byte ptr TextAttr,$F7
  END;

 Procedure NormVideo; Assembler;
  ASM
   mov   al,v0060
   mov   byte ptr TextAttr,al
  END;

 Function KeyPressed; Assembler;
  ASM
   cmp   byte ptr v0061,$00
   jnz   @@0317
   mov   ah,$01
   int   $16
   mov   al,$00
   jz    @@0319
@@0317:
   mov   al,$01
@@0319:
 END;

 Procedure f_0202; Assembler;
  ASM
   push  ax
   call  f_0503
   pop   ax
   mov   bh,byte ptr TextAttr
   mov   cl,byte ptr WindMin
   mov   ch,dh
   mov   dx,WindMax
   cmp   ch,dh
   jne   @@021B
   xor   al,al
@@021b:
   call  f_0614
  END;

 Procedure InsLine; Assembler;
  ASM
   mov   ax,$0701
   jmp   f_0202
  END;

 Procedure DelLine; Assembler;
  ASM
   mov   ax,$0601
   jmp   f_0202
  END;

 Procedure NoSound; Assembler;
  ASM
   in    al,$61
   and   al,$FC
   out   $61,al
  END;

 Procedure Sound; Assembler;
  ASM
   mov   bx,ss:[bp+$04+2]
   mov   ax,$34DD
   mov   dx,$0012
   cmp   dx,bx
   jnc   @@02FE
   div   bx
   mov   bx,ax
   in    al,$61
   test  al,$03
   jnz   @@02F6
   or    al,$03
   out   $61,al
   mov   al,$B6
   out   $43,al
@@02F6:
   mov   al,bl
   out   $42,al
   mov   al,bh
   out   $42,al
@@02FE:
  END;

 Function ReadKey; Assembler;
  ASM
   mov   al,v0061
   mov   v0061,$00
   or    al,al
   jnz   @@0338
   xor   ah,ah
   int   $16
   or    al,al
   jnz   @@0338
   mov   v0061,ah
   or    ah,ah
   jnz   @@0338
   mov   al,$03
@@0338:
   call  f_014E
  END;

 Procedure TextBackground; Assembler;
  ASM
   mov   al,ss:[bp+$04+2]
   and   al,$07
   mov   cl,$04
   shl   al,cl
   and   byte ptr TextAttr,$8F
   or    byte ptr TextAttr,al
  END;

 Procedure TextColor; Assembler;
  ASM
   mov   al,ss:[bp+$04+2]
   test  al,$F0
   je    @@0271
   and   al,$0F
   or    al,$80
@@0271:
   and   byte ptr TextAttr,$70
   or    byte ptr TextAttr,al
  END;

 Procedure TextMode; Assembler;
  ASM
   mov   ax,ss:[bp+$04+2]
   call  f_00A3
   call  f_00F0
   mov   al,v0060
   mov   byte ptr TextAttr,al
  END;

 Function WhereX; Assembler;
  ASM
   call  f_0503
   mov   al,dl
   sub   al,byte ptr WindMin
   inc   al
  END;

 Function WhereY; Assembler;
  ASM
   call  f_0503
   mov   al,dh
   sub   al,v0059
   inc   al
  END;

 Procedure Window; Assembler;
  ASM
   mov   dl,ss:[bp+$0A+2]
   mov   dh,ss:[bp+$08+2]
   mov   cl,ss:[bp+$06+2]
   mov   ch,ss:[bp+$04+2]
   cmp   dl,cl
   ja    @@01C9
   cmp   dh,ch
   ja    @@01C9
   dec   dl
   js    @@01C9
   dec   dh
   js    @@01C9
   dec   cl
   cmp   cl,v005E
   ja    @@01C9
   dec   ch
   cmp   ch,v005F
   ja    @@01C9
   mov   WindMin,dx
   mov   WindMax,cx
   call  f_050A
@@01C9:
  END;

Begin
 Init;
 AssignCRT(Input);
 ReSet(Input);
 AssignCRT(Output);
 ReWrite(Output)
End.
