Unit
	Gfx; { Polit Halcyon Eva graphics unit (interface to mygraph2) }

Interface

Uses
	mygraph2,D,Log,Ini,Types;

Const
	clBlack=0;
	clNavy=1;
	clOlive=2;
	clTeal=3;

	clMaroon=4;
	clPurple=5;
	clBrown=6;
	clSilver=7;

	clGray=8;
	clBlue=9;
	clGreen=10;
	clCyan=11;

	clRed=12;
	clMagenta=13;
	clYellow=14;
	clWhite=15;
		{ additional colors, experimental }
	clMidGray=17;
	clBlueGray=18;
	clNightGray=19;
	clDarkTeal=20;


		{ Basic graphics stuff }
	Procedure Init;
	Procedure SetMode(X,Y,BPP:Integer);

	Procedure ClearDesk;
	Procedure PutPixel(X,Y:Integer;Color:LongInt);
	Function GetPixel(X,Y:Integer):LongInt;
	Procedure Line(X1,Y1,X2,Y2:Integer;Color:LongInt);
	Procedure Rectangle(X1,Y1,X2,Y2:Integer;Color:LongInt);
	Procedure ButtonRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD:LongInt);
	Procedure FillButtonRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD,ColorFill:LongInt);
	Procedure AngleRect(X1,Y1,X2,Y2:Integer;Color:LongInt);
	Procedure TabRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD:LongInt);
	Procedure TabBar(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD,ColorFill:LongInt);
	Procedure Bar(X1,Y1,X2,Y2:Integer;Color:LongInt);

	Procedure InvertBar(X1,Y1,X2,Y2:Integer);
	Procedure InvertFrame(FX1,FY1,FX2,FY2:Integer);
	Procedure InvertBarPlus(X1,Y1,X2,Y2,Color1,Color2:Integer);
	Procedure InvertBarPlusPlus(X1,Y1,X2,Y2,Color1,Color2:Integer);

		{ Image blocks (not small, >64K) }
	Function ImageSize(X,Y:Integer):Word;
	Function ImageSize2(P:Pointer):Word;
	Procedure GetImage(X1,Y1,X2,Y2:Integer;Var P:Pointer);
	Procedure PutImage(X,Y:Integer;P:Pointer);
	Procedure PutSprite(X,Y:Integer;P:Pointer);
	Function ImageX(P:Pointer):Integer;
	Function ImageY(P:Pointer):Integer;

	Procedure AnimateRect(R1,R2:TRect);

	Procedure ShadowPixel(X,Y:Integer);
	Procedure ShadowBar(X1,Y1,X2,Y2:Integer);
	Procedure PutSpriteShadow(X1,Y1,Depth:Integer;P:Pointer);

	Procedure FadeDownPal;
	Procedure FadeUpPal;
	Procedure BlackPal;
	Procedure ReloadPal;
	Procedure SetPalColor(Color,R,G,B:Integer);

	Procedure Done;

Var
	ScrX,ScrY,ScrBPP:Integer;
	DesktopColor:Word;
	AniDelay,FadeDelay:Integer;
	Palette:TPalette;

Implementation

Procedure SetScrParams(SX,SY,SBPP:Integer);
Begin
	ScrX:=SX-1;
	ScrY:=SY-1;
	ScrBPP:=SBPP
End;

Procedure ClearDesk;
Begin
	Bar(0,0,ScrX,ScrY,DesktopColor)
End;

Procedure SetMode(X,Y,BPP:Integer);
Begin
	Log.SysMsg('Gfx','OpenGraphics','X='+D.St(X)+' Y='+D.St(Y)+', BPP='+D.St(BPP));
	SetScrParams(X,Y,BPP);
	If BPP=8 Then
	Begin
		If (X=320) And (Y=200)
			Then mygraph2.InitGraph(V320X200X256)
			Else If (X=640) And (Y=400)
				Then mygraph2.InitGraph(V640X400X256)
				Else If (X=640) And (Y=480)
					Then mygraph2.InitGraph(V640X480X256)
					Else If (X=800) And (Y=600)
						Then mygraph2.InitGraph(V800X600X256)
						Else If (X=1024) And (Y=768)
							Then mygraph2.InitGraph(V1024X768X256)
							Else If (X=1280) And (Y=1024)
								Then mygraph2.InitGraph(V1280X1024X256)
								Else Begin
									Log.ErrMsg('Gfx','OpenGraphics','unknown 8 BPP video mode');
									Log.ActMsg('Setting 800x600x256');
									mygraph2.InitGraph(V800X600X256);
									SetScrParams(800,600,8)
								End
	End
	Else Begin
		Log.ErrMsg('Gfx','OpenGraphics','only 8 BPP modes supported');
		Log.ActMsg('Setting 800x600x256');
		mygraph2.InitGraph(V800X600X256);
		SetScrParams(800,600,8)
	End;
	If mygraph2.GraphResult=grOK
		Then Log.SysMsg('Gfx','OpenGraphics','Graphics mode opened (VESA supported)')
		Else Begin
			Log.FatMsg('Gfx','OpenGraphics','Cannot open graphics mode :(');
			Log.ActMsg('VESA or this video mode is not supported by your video card');
			Log.Done;
			Halt(13)
		End;
	mygraph2.GetAllPalette(@Palette);
End;

Procedure PutPixel(X,Y:Integer;Color:LongInt);
Begin
	mygraph2.PutPixel(X,Y,Color)
End;

Function GetPixel(X,Y:Integer):LongInt;
Begin
	GetPixel:=mygraph2.GetPixel(X,Y)
End;

Procedure Line(X1,Y1,X2,Y2:Integer;Color:LongInt);
Begin
	mygraph2.SetColor(Color);
	mygraph2.Line(X1,Y1,X2,Y2)
End;

Procedure Rectangle(X1,Y1,X2,Y2:Integer;Color:LongInt);
Begin
	mygraph2.SetColor(Color);
	mygraph2.Rectangle(X1,Y1,X2,Y2)
End;

Procedure ButtonRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD:LongInt);
Begin
	mygraph2.SetColor(ColorLU);
	mygraph2.Line(X1,Y1,X2,Y1);
	mygraph2.Line(X1,Y1+1,X1,Y2-1);
	mygraph2.SetColor(ColorRD);
	mygraph2.Line(X1,Y2,X2,Y2);
	mygraph2.Line(X2,Y1+1,X2,Y2-1);

	{mygraph2.PutPixel(X1+1,Y1+1,ColorLU);
	mygraph2.PutPixel(X2-1,Y2-1,ColorRD)}
End;

Procedure FillButtonRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD,ColorFill:LongInt);
Begin
	ButtonRect(X1,Y1,X2,Y2,ColorLU,ColorRD);
	mygraph2.SetColor(ColorFill);
	mygraph2.Bar(X1+1,Y1+1,X2-1,Y2-1);
	{mygraph2.PutPixel(X1+1,Y1+1,ColorLU);
	mygraph2.PutPixel(X2-1,Y2-1,ColorRD)}
End;

Procedure AngleRect(X1,Y1,X2,Y2:Integer;Color:LongInt);
Begin
	mygraph2.SetColor(Color);
	mygraph2.Line(X1,Y1,X2,Y1);
	mygraph2.Line(X1,Y1+1,X1,Y2)
End;

Procedure TabRect(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD:LongInt);
Begin
	mygraph2.SetColor(ColorLU);
	mygraph2.Line(X1,Y1,X2,Y1);
	mygraph2.Line(X1,Y1+1,X1,Y2);
	mygraph2.SetColor(ColorRD);
	mygraph2.Line(X2,Y1+1,X2,Y2)
End;

Procedure TabBar(X1,Y1,X2,Y2:Integer;ColorLU,ColorRD,ColorFill:LongInt);
Begin
	TabRect(X1,Y1,X2,Y2,ColorLU,ColorRD);
	mygraph2.SetColor(ColorFill);
	mygraph2.Bar(X1+1,Y1+1,X2-1,Y2)
End;


Procedure Bar(X1,Y1,X2,Y2:Integer;Color:LongInt);
Begin
	mygraph2.SetColor(Color);
	mygraph2.Bar(X1,Y1,X2,Y2)
End;



Function ImageSize(X,Y:Integer):Word;
Begin
	ImageSize:=mygraph2.ImageSize(0,0,X,Y)
End;

Function ImageSize2(P:Pointer):Word;
Begin
	ImageSize2:=ImageSize(ImageX(P),ImageY(P))
End;

Procedure InvertBar(X1,Y1,X2,Y2:Integer);
Var
	P:Pointer;
	S:Word;
	I:Word;
Begin
	S:=mygraph2.ImageSize(X1,Y1,X2,Y2);
	GetMem(P,S);
	mygraph2.GetImage(X1,Y1,X2,Y2,P);
	For I:=4 To S Do
		TMatrix(P^)[I]:=Not TMatrix(P^)[I];
	mygraph2.PutImage(X1,Y1,P);
	FreeMem(P,S)
End;

Procedure InvertBarPlus(X1,Y1,X2,Y2,Color1,Color2:Integer);
Var
	P:Pointer;
	S:Word;
	I:Word;
Begin
	S:=mygraph2.ImageSize(X1,Y1,X2,Y2);
	GetMem(P,S);
	mygraph2.GetImage(X1,Y1,X2,Y2,P);
	For I:=4 To S Do
		If TMatrix(P^)[I]=Color1
			Then TMatrix(P^)[I]:=Color2
			Else TMatrix(P^)[I]:=Color1;
	mygraph2.PutImage(X1,Y1,P);
	FreeMem(P,S)
End;

Procedure InvertBarPlusPlus(X1,Y1,X2,Y2,Color1,Color2:Integer);
Var
	P:Pointer;
	S:Word;
	I:Word;
Begin
	S:=mygraph2.ImageSize(X1,Y1,X2,Y2);
	GetMem(P,S);
	mygraph2.GetImage(X1,Y1,X2,Y2,P);
	For I:=4 To S Do
		If TMatrix(P^)[I]=Color1
			Then TMatrix(P^)[I]:=Color2;
	mygraph2.PutImage(X1,Y1,P);
	FreeMem(P,S)
End;

Procedure InvertFrame(FX1,FY1,FX2,FY2:Integer);
Begin
	InvertBar(FX1,FY1,FX2,FY1);
	InvertBar(FX1,FY2,FX2,FY2);
	InvertBar(FX1,FY1+1,FX1,FY2-1);
	InvertBar(FX2,FY1+1,FX2,FY2-1)
End;

Procedure GetImage(X1,Y1,X2,Y2:Integer;Var P:Pointer);
Begin
	mygraph2.GetImage(X1,Y1,X2,Y2,P)
End;

Procedure PutImage(X,Y:Integer;P:Pointer);
Begin
	mygraph2.PutImage(X,Y,P)
End;

Procedure PutSprite(X,Y:Integer;P:Pointer);
Begin
	mygraph2.PutSprite(X,Y,P)
End;

Function ImageX(P:Pointer):Integer;
Begin
	ImageX:=TMatrix2(P^)[0]
End;

Function ImageY(P:Pointer):Integer;
Begin
	ImageY:=TMatrix2(P^)[1]
End;








Procedure AnimateRect(R1,R2:TRect);
Var
	Last:TRect;
	DX1,DX2,DY1,DY2:Real;
	X1,Y1,X2,Y2,Temp:Real;
	Steps,I:Integer;
	Dl:Integer;
Begin
	Steps:=Abs(R1.X1-R2.X1)+Abs(R1.X2-R2.X2)+Abs(R1.Y1-R2.Y1)+Abs(R1.Y2-R2.Y2);
	Steps:=Steps Div (ScrY Div 10);
	If Steps=0 Then Exit;
	DX1:=(R2.X1-R1.X1)/Steps;
	DX2:=(R2.X2-R1.X2)/Steps;
	DY1:=(R2.Y1-R1.Y1)/Steps;
	DY2:=(R2.Y2-R1.Y2)/Steps;

	Last:=R1;
	X1:=R1.X1+DX1;
	X2:=R1.X2+DX2;
	Y1:=R1.Y1+DY1;
	Y2:=R1.Y2+DY2;

	InvertFrame(R1.X1,R1.Y1,R1.X2,R1.Y2);
	InvertFrame(Round(X1),Round(Y1),Round(X2),Round(Y2));

	For I:=2 To Steps Do
	Begin
		InvertFrame(Last.X1,Last.Y1,Last.X2,Last.Y2);

		Last.X1:=Round(X1);
		Last.X2:=Round(X2);
		Last.Y1:=Round(Y1);
		Last.Y2:=Round(Y2);

		X1:=X1+DX1;
		X2:=X2+DX2;
		Y1:=Y1+DY1;
		Y2:=Y2+DY2;

		InvertFrame(Round(X1),Round(Y1),Round(X2),Round(Y2));
		For Dl:=0 To AniDelay Do
			Temp:=Sin(Dl)
	End;
	InvertFrame(Last.X1,Last.Y1,Last.X2,Last.Y2);
	InvertFrame(Round(X1),Round(Y1),Round(X2),Round(Y2))
End;

Procedure ShadowPixel(X,Y:Integer);
Const
	TransColor:Array[0..20] Of Byte=
		(0,0,0,0, 0,0,0,8, 0,1,2,3, 4,5,6,7, 0,19,1,0,0);
Var
	Color:Byte;
Begin
	Color:=mygraph2.GetPixel(X,Y);
	If Color<=20
		Then mygraph2.PutPixel(X,Y,TransColor[Color])
		Else mygraph2.PutPixel(X,Y,clBlack)
End;

Procedure ShadowBar(X1,Y1,X2,Y2:Integer);
Var
	X,Y:Integer;
Begin
	For Y:=Y1 To Y2 Do
		For X:=X1 To X2 Do
			ShadowPixel(X,Y)
End;

Procedure PutSpriteShadow(X1,Y1,Depth:Integer;P:Pointer);
Const
	TranspColor=0;
Var
	X,Y:Integer;
	Width:Integer;
Begin
	mygraph2.PutSprite(X1,Y1,P);
	Width:=TMatrix2(P^)[0];
	For Y:=Depth To TMatrix2(P^)[1]-1 Do
		For X:=Depth To Width-1 Do
			If (TMatrix(P^)[4+Y*Width+X]=TranspColor) And
				(TMatrix(P^)[4+(Y-Depth)*Width+(X-Depth)]<>TranspColor) Then
				ShadowPixel(X1+X,Y1+Y);
	For X:=Width To Width+Depth-1 Do
		For Y:=Depth To TMatrix2(P^)[1]-1 Do
			If TMatrix(P^)[4+(Y-Depth)*Width+(X-Depth)]<>TranspColor Then
				ShadowPixel(X1+X,Y1+Y);
	For Y:=TMatrix2(P^)[1] To TMatrix2(P^)[1]+Depth-1 Do
		For X:=Depth To Width+Depth-1 Do
			If TMatrix(P^)[4+(Y-Depth)*Width+(X-Depth)]<>TranspColor Then
				ShadowPixel(X1+X,Y1+Y);
End;



Procedure FadeDownPal;
Var
	TempPal:TPalette;
	I,Dl:Integer;
	Temp:Real;
Begin
	TempPal:=Palette;
	For I:=1 To 64 Do
	Begin
		mygraph2.FadeDown(@TempPal,1);
		mygraph2.SetAllPalette(@TempPal);
		For Dl:=1 To FadeDelay Do
			Temp:=Sin(Dl)
	End
End;

Procedure FadeUpPal;
Var
	TempPal:TPalette;
	I,J,Dl:Integer;
	Temp:Real;
Begin
	For I:=63 DownTo 0 Do
	Begin
		TempPal:=Palette;
		For J:=0 To 255 Do
		Begin
			If TempPal[J].R>I
				Then Dec(TempPal[J].R,I)
				Else TempPal[J].R:=0;
			If TempPal[J].G>I
				Then Dec(TempPal[J].G,I)
				Else TempPal[J].G:=0;
			If TempPal[J].B>I
				Then Dec(TempPal[J].B,I)
				Else TempPal[J].B:=0
		End;
		mygraph2.SetAllPalette(@TempPal);
		For Dl:=1 To FadeDelay Do
			Temp:=Sin(Dl)
	End
End;


Procedure BlackPal;
Var
	TempPal:TPalette;
	I:Integer;
Begin
	For I:=0 To 255 Do
	Begin
		TempPal[I].R:=0;
		TempPal[I].G:=0;
		TempPal[I].B:=0
	End;
	mygraph2.SetAllPalette(@TempPal)
End;

Procedure ReloadPal;
Begin
	mygraph2.SetAllPalette(@Palette)
End;

Procedure SetPalColor(Color,R,G,B:Integer);
Begin
	mygraph2.SetRGBPalette(Color,(R+1) Div 4,(G+1) Div 4,(B+1) Div 4)
End;






Procedure Init;
Var
	Temp:String;
	X,Y,BPP:Integer;
	Res:Word;
	F:Text;
	I:Integer;
Begin
	Log.SysMsg('Gfx','Init','Graphics init sequence started');
	Ini.SetSection('Graphics');

	X:=Ini.GetInt('X',800);
	Y:=Ini.GetInt('Y',600);
	BPP:=Ini.GetInt('BPP',8);
	SetMode(X,Y,BPP);
	AniDelay:=Ini.GetInt('AniDelay',900);
	FadeDelay:=Ini.GetInt('FadeDelay',1200);
	DesktopColor:=Ini.GetInt('DesktopColor',clNavy);

		{ Load & set palette }
	Temp:=Ini.GetStr('Palette','polit.pal');
	If Not D.FileExist(Temp) Then
	Begin
		Log.ErrMsg('Gfx','Init','Palette file not found: '+Temp);
		Log.ActMsg('Ignoring palette set request');
		Exit
	End;
	Assign(F,Temp);
	Reset(F);
	I:=0;
	Repeat
		With Palette[I] Do
		Begin
			ReadLn(F,R,G,B);
			R:=R Div 4;
			G:=G Div 4;
			B:=B Div 4;
			If I<128 Then
			Begin { �� �� ������ ��㣠 �������� ���i�� - i�����i ����� }
				Palette[255-I].R:=63-R;
				Palette[255-I].G:=63-G;
				Palette[255-I].B:=63-B
			End
		End;
		Inc(I)
	Until EOF(F) Or (I>255);
	If I>255 Then
	Begin
		Log.ErrMsg('Gfx','Init','Palette file '+Temp+' contains more than 256 colors.');
		Log.ActMsg('Ignoring other colors.')
	End;
	mygraph2.SetAllPalette(@Palette);
	Close(F);
	ClearDesk
End;


Procedure Done;
Begin
	Log.SysMsg('Gfx','Init','Graphics shutdown sequence started');
	CloseGraph
End;

Begin End.