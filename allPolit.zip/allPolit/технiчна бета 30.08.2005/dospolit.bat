addon\ctmouse.exe
polit.exe